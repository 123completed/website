function calcSum(x,y){
	return x+y;
}